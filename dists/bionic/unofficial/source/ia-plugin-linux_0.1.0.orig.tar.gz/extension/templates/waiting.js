import h from 'hyperscript'

export default function waiting() {
  return h('div', h('h1', 'Thinking...'))
}
